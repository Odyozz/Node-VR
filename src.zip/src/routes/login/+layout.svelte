<!-- src/routes/login/+layout.svelte -->
<script>
  // Tu peux mettre du code ici si besoin, ou le supprimer si pas utile
</script>

<slot />
