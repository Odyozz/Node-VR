<h2 class="text-2xl font-bold">Alliance</h2><p>Page alliance en construction...</p>
