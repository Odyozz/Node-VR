<!-- On cache la navbar ici, layout minimal -->
<slot />
